<?php include('header.php'); ?>

<!--BODY SECTION  -->
<div class="row" style="margin-top: 70px; margin-bottom: 70px">
	
<?php include('myPageView.php'); ?>
	
</div>

<!--BODY SECTION END  -->

<?php include("footer.php");?>
