</div>
<!-- Footer area -->
	 	<div class="container-fluid" style="background-color: #337AB7;">
	 		<div class="container">
	 			<div class="row">
	 				<div class="col-lg-12">
	 					<a href="" style="text-decoration: none;"><h3 style="color: #fff;">ABOUT US</h3></a>
	 					<p style="color: #fff; font-size: 15px;">Anlics technologies is an global multimedia, technology, news, entertainment and digital media Based company .We deliver premieum, Inspiring and motivational content across the world.</p>
	 					<p style="color: #fff;text-align: center;"><span class="fa fa-user" style="color: orange; font-size: 18px;"></span>&nbsp;&nbsp;&nbsp;&nbsp;Suite 2213, Doon Business Park, Dehradun 248001  
	 					<span class="fa fa-phone" style="color: orange; font-size: 18px;"></span>&nbsp;&nbsp;&nbsp;&nbsp;+91-7500756437
	 					<span class="fa fa-envelope" style="color: orange; font-size: 18px;"></span>&nbsp;&nbsp;&nbsp;&nbsp;info@anlics.com</p>
	 				</div> <!-- COL 1 -->
	 			</div>

	 			<div class="row" id="footeranlics">
	 				<div class="col-lg-12 text-center">
	 					<p style="color: #fff; margin-top: 5px;"><a href="" style="color: #fff;">Anlics</a> <span class="fa fa-copyright"></span> 2018. All Rights Reserved.</p>
	 				</div>
	 			</div>
	 		</div>
	 	</div>
	<!-- end of footer area -->
<!--javascript-->
<script>
// Get the modal
var modal = document.getElementById('id01');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
</script>
<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<!--javascript End-->
</body>
</html>