
<?php include('userHeader.php'); ?>

<!--BODY SECTION  -->

<div class="row clearfix">
	
	<?php include ('userMainPage.php'); ?>


	<?php include ('userRightSide.php');?>
	
</div>
<div class="row">
	<?php include('moreViews.php');?>
</div>

<!--BODY SECTION END  -->


<?php include("userFooter.php");?>
