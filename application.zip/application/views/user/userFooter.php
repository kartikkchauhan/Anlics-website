</div>
<!-- Footer area -->
	 	<div class="container-fluid" style="background-color: #337AB7;">
	 		<div class="container">
	 			<div class="row">
	 				<div class="col-lg-4">
	 					<a href="" style="text-decoration: none;"><h3 style="color: #fff;">ABOUT US</h3></a>
	 					<p style="color: #fff; font-size: 15px;">Anlics technologies is an global multimedia, technology, news, entertainment and digital media Based company .We deliver premieum, Inspiring and motivational content across the world.</p>
	 					<p style="color: #fff;"><span class="fa fa-map-marker" style="color: orange; font-size: 18px;"></span>&nbsp;&nbsp;&nbsp;&nbsp;Suite 2213, Doon Business Park, Dehradun 248001</p>
	 					<p style="color: #fff;"><span class="fa fa-phone" style="color: orange; font-size: 18px;"></span>&nbsp;&nbsp;&nbsp;&nbsp;<a href="tel:+91-7500756437" style="text-decoration: none; color: white">+91-7500756437</a></p>
	 					<p style="color: #fff;"><span class="fa fa-envelope" style="color: orange; font-size: 18px;"></span>&nbsp;&nbsp;&nbsp;&nbsp;<a href="mailto:info@anlics.com" style="text-decoration: none; color: white">info@anlics.com</a></p>
	 				</div> <!-- COL 1 -->

	 				<div class="col-lg-4">
	 					<h3 style="color: #fff;">MENU</h3>
	 					<ul type="circle" class="col-lg-5" style="color: #fff;">
	 						<li><a href="<?= base_url('user/news') ?>" style="color: #fff;">NEWS</a></li>
	 						<li><a href="" style="color: #fff;">VIDEOS</a></li>
	 						<li><a href="<?= base_url('user/education') ?>" style="color: #fff;">CAREER</a></li>
	 						<li><a href="<?= base_url('user/technology') ?>" style="color: #fff;">TECHNOLOGIES</a></li>
	 						<li><a href="<?= base_url('user/gadgets') ?>" style="color: #fff;">GADGETS</a></li>
	 						<li><a href="<?= base_url('user/automobiles') ?>" style="color: #fff;">AUTOMOBILES</a></li>
	 						<li><a href="<?= base_url('user/tour_travels') ?>" style="color: #fff;">TOUR & TRAVELS</a></li>
	 					</ul>
	 					<ul type="circle" class="col-lg-5" style="color: #fff;">
	 						<li><a href="<?= base_url('user/entertainment') ?>" style="color: #fff;">ENTERTAINMENT</a></li>
	 						<li><a href="<?= base_url('user/foods') ?>" style="color: #fff;">FOODS</a></li>
	 						<li><a href="<?= base_url('user/sports') ?>" style="color: #fff;">SPORTS</a></li>
	 						<li><a href="<?= base_url('user/photos') ?>" style="color: #fff;">PHOTOS</a></li>
	 						<li><a href="<?= base_url('user/health_fitness') ?>" style="color: #fff;">HEALTH & FITNESS</a></li>
	 					</ul>
	 				</div> <!-- COL 2 -->


	 				<div class="col-lg-4">
	 					<h3 style="color: #fff;">GIVE US FEEDBACK</h3>
	 					<input type="text" name="name" placeholder="&nbsp;&nbsp;Name*" style="background-color: #fff;
						width: 85%; height: 45px; margin-top: 5px; margin-bottom: 5px; border: 1px solid #ABB1BA; border-radius: 30px; color: #fff;"><br>
	 					<input type="text" name="email" placeholder="&nbsp;&nbsp;Email*" style="background-color: #fff;
						width: 85%; height: 45px; margin-top: 5px; margin-bottom: 5px; border: 1px solid #ABB1BA; border-radius: 30px; color: #fff;"><br>
	 					<input type="text" name="message" placeholder="&nbsp;&nbsp;Message" style="background-color: #fff;
						width: 85%; height: 45px; margin-top: 5px; margin-bottom: 5px; border: 1px solid #ABB1BA; border-radius: 30px; color: #fff;"><br>
	 					<button class="btn btn-default" style="margin-left: 5px; width: 100px; height: 40px; border-radius: 20px; font-size: 18px;">Send</button>
	 				</div> <!-- COL 3 -->
	 			</div>

	 			<div class="row" id="footeranlics">
	 				<div class="col-lg-12">
	 					<p style="color: #fff; margin-top: 5px;"><a href="" style="color: #fff;">Anlics</a> <span class="fa fa-copyright"></span> 2018. All Rights Reserved.</p>
	 				</div>
	 			</div>
	 		</div>
	 	</div>
	<!-- end of footer area -->
<!--javascript-->
<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<!--javascript End-->
</body>
</html>