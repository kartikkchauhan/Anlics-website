<?php include('userHeader.php'); ?>

<!--BODY SECTION  -->

<div class="row">
	
	<?php include ('write.php'); ?>
	
</div>

<!--BODY SECTION END  -->


<?php include("userFooter.php");?>
