<div class="row" style="background-color: #3479B6; height: 60px;">
				<center>
					<h4 style="color: #fff; margin-top: 18px;">&nbsp;<span class="fa fa-copyright"></span>&nbsp;2018 <a href="" style="color: #fff;">Anlics.com</a> . All Rights Reserved | Design by <a href="" style="color: #fff;">Anlics.com</a></h4>
				</center>
			</div> <!-- ROW 3 -->
		</div> <!-- end of container-fluid area -->

	<!-- javascript files area -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</body>
</html>