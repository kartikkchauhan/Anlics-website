<div class="col-lg-10">
					<div class="row col-lg-offset-0" style="margin-top: 30px; margin-left: 30px;">
						<h4><a href="<?= base_url('admin/admin_dashboard') ?>" style="color: #3479B6; text-decoration: none;">Home</a> / <a href="<?= base_url('admin/manage_admin') ?>" style="color: #3479B6; text-decoration: none;">Manage Admin</a> / Update Admin</h4>
					</div>
					<div class="row" style="margin-left: 1px;">
						<div class="col-lg-5">
							<div class="row" style="margin-left: 15px;">
								<h1>UPDATE ADMIN</h1>
							</div>
						</div>
					</div><br> <!-- ROW 1 -->

					<div class="row col-lg-offset-0 img-rounded" style="background-color: #3479B6;">
						<div class="col-lg-2">
							<h4 class="text-center" style="color: #fff;">DATE / TIME</h4>
						</div>
						<div class="col-lg-2">
							<h4 class="text-center" style="color: #fff;">ADMIN NAME</h4>
						</div>
						<div class="col-lg-4">
							<h4 class="col-lg-offset-2" style="color: #fff;">EMAIL ADDRESS</h4>
						</div>
						<div class="col-lg-2">
							<h4 class="col-lg-offset-2" style="color: #fff;">IP ADDRESS</h4>
						</div>
						<div class="col-lg-2">
							<h4 class="col-lg-offset-1" style="color: #fff;">ADMIN AREA</h4>
						</div>
					</div>

				<!-- main row area -->
					<div class="row col-lg-offset-0" style="height: 378px; overflow-x: hidden; overflow-y: scroll;">
						<div id="alladmin" class="row col-lg-offset-0" style="margin-top: 10px;">
							<div class="col-lg-2">
								<h4>06-02-2018 2:15</h4><br>
							</div>
							<div class="col-lg-2">
								<p class="col-lg-offset-1" style="font-size: 18px; margin-top: 5px;">Kartik Chauhan</p>
							</div>
							<div class="col-lg-4 col-lg-offset-0">
								<p class="col-lg-offset-1" style="font-size: 18px; margin-top: 5px;">kartikchauhan100@gmail.com</p>
							</div>
							<div class="col-lg-2">
								<p class="col-lg-offset-2" style="font-size: 18px; margin-top: 5px;">102.20.30.15</p>
							</div>
							<div id="UPDATE" class="col-lg-2">
								<button class="btn btn-primary" style="margin-left: 15px;">UPDATE <span class="fa fa-check"></span></button>
							</div>
						</div><br><br> <!-- ROW 1.1 -->

						<div id="updateadmin" class="row col-lg-offset-2 form-control" style="width: 50%; height: 265px; border-radius: 40px;"><br>
							<div class="row col-lg-offset-2">
									<input type="text" name="admin_name" placeholder="Update your name..." style="width: 70%; height: 40px; border: 2px solid #3479B6; padding-left: 5px; color: #3479B6; font-size: 15px;" />
							</div><br>
							<div class="row col-lg-offset-2">
									<input type="text" name="admin_name" placeholder="Update your email address..." style="width: 70%; height: 40px; border: 2px solid #3479B6; padding-left: 5px; color: #3479B6; font-size: 15px;" />
							</div><br>
							<div class="row col-lg-offset-2">
									<input type="text" name="admin_name" placeholder="Update your password..." style="width: 70%; height: 40px; border: 2px solid #3479B6; padding-left: 5px; color: #3479B6; font-size: 15px;" />
							</div><br>
							<div class="row">
								<div class="col-lg-6">
									<button id="update" class="btn btn-primary col-lg-offset-10">Update <span class="fa fa-check"></span></button>
								</div>
								<div class="col-lg-6">
									<button id="cancel" class="btn btn-primary" style="margin-left: 30px;">CANCEL <span class="fa fa-remove"></span></button>
								</div>
							</div>
						</div> <!-- UPDATE ADMIN AREA -->

					</div> <!-- end of main row area -->

				</div> <!-- end of right area -->