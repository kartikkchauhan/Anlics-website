<div class="col-lg-10">
					<div class="row">
						<div class="col-lg-3 well" style="background-color: #3479B6; color: #fff; height: 125px;">
							<div class="row" style="margin-left: 15px;">
								<div class="col-lg-5">
									<h3>USERS</h3>
								</div>
								<div class="col-lg-5">
									<h3>100</h3>
								</div>
							</div>
							
						
						</div>
						<div class="col-lg-3 well" style="background-color: #F1F1F1; color: #3479B6; border: 2px solid #D9D9D9; height: 125px;">
							<div class="row" style="margin-left: 15px;">
								<div class="col-lg-7">
									<h3>VISITORS</h3>
								</div>
								<div class="col-lg-5">
									<h3>100</h3>
								</div>
							</div>
						</div>
						<div class="col-lg-3 well" style="background-color: #3479B6; color: #fff; height: 125px;">
							<div class="row" style="margin-left: 15px;">
								<div class="col-lg-7">
									<h3>ARTICLES</h3>
								</div>
								<div class="col-lg-5">
									<h3>100</h3>
								</div>
							</div>
						</div>
						<div class="col-lg-3 well" style="background-color: #F1F1F1; color: #3479B6; border: 2px solid #D9D9D9; height: 125px;">
							<div class="row" style="margin-left: 15px;">
								<div class="col-lg-7">
									<h3>ARTICLES REQUEST</h3>
								</div>
								<div class="col-lg-5">
									<h3>100</h3>
								</div>
							</div>
						</div>
					</div> <!-- ROW 1 -->

					<div class="row" style="margin-top: 20px; height: 440px;">
						<div class="col-lg-6" style="height: 335px;">
							<h4 style="float: left;">To</h4>
							<div class="row form-control" style="width: 93%; margin-left: 25px; border-top-left-radius: 10px; border-bottom-right-radius: 10px; border: 2px solid #3479B6; padding-left: 5px;"></div><br>
							<h4 style="float: left;">Message&nbsp;</h4>
							<textarea style="width: 84%; height: 220px; border: 1px solid #D9D9D9; border: 2px solid #3479B6; padding-left: 10px; padding-top: 10px;" placeholder="Send Message..."></textarea>
							<button class="btn btn-primary pull-right" style="margin-right: 8px; margin-top: 8px; width: 20%; font-size: 18px;">SEND <span class="fa fa-check"></span></button>
						</div>
						<div class="col-lg-6" style="">
							<div class="row" style="height: 335px; border: 1px solid #D9D9D9;">
								<div class="col-lg-12" style="margin: 4px;">
									<img src="<?= base_url('uploads/dummy/user.png') ?>" style="width: 60px; height: 60px; border-radius: 50%;">
									<span style="margin-left: 20px;">Hellow my name is Kartik Chauhan</span>
								</div>
								<div class="col-lg-12" style="margin: 4px;">
									<img src="<?= base_url('uploads/dummy/user.png') ?>" style="width: 60px; height: 60px; border-radius: 50%;">
									<span style="margin-left: 20px;">Hellow my name is Kartik Chauhan</span>
								</div>
								<div class="col-lg-12" style="margin: 4px;">
									<img src="<?= base_url('uploads/dummy/user.png') ?>" style="width: 60px; height: 60px; border-radius: 50%;">
									<span style="margin-left: 20px;">Hellow my name is Kartik Chauhan</span>
								</div>
								<div class="col-lg-12" style="margin: 4px;">
									<img src="<?= base_url('uploads/dummy/user.png') ?>" style="width: 60px; height: 60px; border-radius: 50%;">
									<span style="margin-left: 20px;">Hellow my name is Kartik Chauhan</span>
								</div>
								<div class="col-lg-12" style="margin: 4px;">
									<img src="<?= base_url('uploads/dummy/user.png') ?>" style="width: 60px; height: 60px; border-radius: 50%;">
									<span style="margin-left: 20px;">Hellow my name is Kartik Chauhan</span>
								</div>
							</div>
						</div>
					</div> <!-- ROW 2 -->

				</div> <!-- end of right area -->