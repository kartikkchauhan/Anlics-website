				<div class="col-lg-10">
					<div class="row col-lg-offset-0" style="margin-top: 30px;">
						<h4><a href="<?= base_url('admin/admin_dashboard') ?>" style="color: #3479B6; text-decoration: none;">Home</a> / Manage Article</h4>
					</div>
					<div class="row col-lg-offset-0">
						<a href="<?= base_url('admin/live_article') ?>" style="color: #fff;"><div class="col-lg-4 well" style="background-color: #3479B6; color: #fff; height: 125px;">
							<div class="row" style="margin-left: 15px;">
								<div class="col-lg-5">
									<h3>LIVE ARTICLES</h3>
								</div>
								<div class="col-lg-5" style="margin-left: 30px; margin-top: 10px;">
									<h3>100</h3>
								</div>
							</div>
						</div></a>

						<a href="<?= base_url('admin/article_request') ?>" style="color: #3479B6;"><div class="col-lg-4 well" style="background-color: #F1F1F1; color: #3479B6; border: 2px solid #D9D9D9; height: 125px;">
							<div class="row" style="margin-left: 15px;">
									<div class="col-lg-7">
										<h3>ARTICLES REQUEST</h3>
									</div>
									<div class="col-lg-5" style="margin-top: 10px;">
										<h3>100</h3>
									</div>
								</div>
						</div></a>
						
						<a href="<?= base_url('admin/all_articles') ?>" style="color: #fff;"><div class="col-lg-4 well" style="background-color: #3479B6; color: #fff; height: 125px;">
							<div class="row" style="margin-left: 15px;">
									<div class="col-lg-7">
										<h3>ALL ARTICLES</h3>
									</div>
									<div class="col-lg-5">
										<h3>100</h3>
									</div>
								</div>
						</div></a>
					</div> <!-- ROW 1 -->

					<div class="row" style="height: 440px;">
						<div class="col-lg-6" style="">
							<div style="border: 1px solid #D9D9D9; height: 335px;"><br>
							
						</div>
						</div>
						<div class="col-lg-6" style="">
							<div class="row" style="height: 335px; border: 1px solid #D9D9D9;">
								
							</div>
						</div>
					</div> <!-- ROW 2 -->

				</div> <!-- end of right area -->