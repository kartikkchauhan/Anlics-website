			<!-- header area -->
			<?php include ("header.php"); ?>

			<!-- body area -->
			<div class="row" style="margin-top: 51px; background-color: #EDEDED;">

				<!-- left side area -->
				<?php include ("leftside.php"); ?>

				<!-- right side area -->
				<?php include ("viewwritterright.php"); ?>
			</div>
			
			<!-- footer area -->
			<?php include("footer.php"); ?>